i = 0 
rn = 1
cid = 100
totalbill = 0
booked_rooms = {}
valid_customer_ids = {}


def Home():
    print("\t\t\t\t Welcome to Hotel Piyush\n")
    print("\t\t\t 1 Booking\n")
    print("\t\t\t 2 Room info\n")
    print("\t\t\t 3 Restaurant\n")
    print("\t\t\t 4 Payment\n")
    print("\t\t\t 5 Record\n") 
    print("\t\t\t 6 Exit\n")
    
    ch = int(input("-> "))
    match ch:
        case 1:
            print(" ")
            BOOKING()
        case 2:
            print(" ")
            Room_info()
        case 3:
            print(" ")
            Restaurant()
        case 4:
            print(" ")
            Payment()
        case 5:
            print(" ")
            Record()  
        case _:
            exit()

def BOOKING():
    global rn, cid, booked_rooms, valid_customer_ids
    print("Booking room")
    print(" ")
    Price = 0
    while True:
        n = str(input("Name: "))
        p = str(input("Phone No: "))
        if len(p) != 10 or not p.isdigit():
            print("Invalid phone number. Please enter exactly 10 digits.")
            continue
        
        a = str(input("Address: "))
        
        if n != "" and p != "" and len(p) == 10 and p.isdigit() and a != "":
            break 
        else:
            print("Please fulfill all the data")
    
    print("\t\t\t SELECT ROOM TYPE\n")
    print("\t\t\t 1 STANDARD NON-AC ROOM \n")
    print("\t\t\t 2 STANDARD AC ROOM\n")
    print("\t\t\t 3 3 Bed Non-AC Room\n")
    print("\t\t\t 4 3 Bed AC Room\n")
    print("\t\t\t 5 Press 0 for Room Prices\n")
    
    ch = int(input("-> "))
    if ch == 0:
        print(" 1 STANDARD NON AC ROOM - Rs. 3500")
        print(" 2 STANDARD AC ROOM- Rs. 4000")
        print(" 3 3 Bed Non-AC Room- Rs. 4500")
        print(" 4 3 Bed AC room - Rs. 5000")
        ch = int(input("-> "))
    
    if ch == 1:
        RoomType = "STANDARD NON AC ROOM"
        Price = 3500
    elif ch == 2:
        RoomType = "STANDARD AC ROOM"
        Price = 4000
    elif ch == 3:
        RoomType = "3 Bed Non-AC ROOM"
        Price = 4500
    elif ch == 4:
        RoomType = "3 Bed AC ROOM"
        Price = 5000
    else:
        print("Wrong choice....")
        return
    
    if rn in booked_rooms:
        print("Room is already booked.")
    else:
        print("")
        print("\t\t\t***ROOM BOOKED SUCCESSFULLY***\n")
        print("Room No. - ", rn)
        print("Customer Id - ", cid)
          
        booked_rooms[rn] = {"name": n, "phone": p, "address": a, "Room Type": RoomType, "Price": Price}
        valid_customer_ids[str(cid)] = {"name": n, "phone": p, "address": a, "Room Type": RoomType, "Price": Price}
        rn += 1
        cid += 1
    
    n = int(input("0-BACK\n -> "))
    if n == 0:
        Home()
    else:
        exit()

def Room_info():
    print("Room information")
    print(" ")
    print("STANDARD NON-AC ROOM")
    print(" ")
    print("1 Double Bed, Television, Telephone,")
    print("Double-Door Cupboard, 1 Coffee table with 2 sofa, Balcony and")
    print("an attached washroom with hot/cold water.\n")
    print("STANDARD AC ROOM")
    print(" ")
    print("1 Double Bed, Television, Telephone,")
    print("Double-Door Cupboard, 1 Coffee table with 2 sofa, Balcony and")
    print("an attached washroom with hot/cold water.\n") 
    print("3 Bed Non-AC Room-")
    print(" ")
    print("1 Double Bed, 1 Single Bed, Television, Telephone,")
    print("Double-Door Cupboard, 1 Coffee table with 2 sofa, Balcony and")
    print("an attached washroom with hot/cold water.\n")
    print("3 Bed AC Room-")
    print(" ")
    print("1 Double Bed, 1 Single Bed, Television, Telephone, AC")
    print("Double-Door Cupboard, 1 Coffee table with 2 sofa, Balcony and")
    print("an attached washroom with hot/cold water.\n")
    n = int(input("0-BACK\n -> "))
    if n == 0:
        Home()
    else:
        exit()

def Restaurant():
    global totalbill
    print("Welcome to Hotel Piyush")
    customer_id = input("Please enter your customer ID: ")

    if customer_id not in valid_customer_ids:
        print("Invalid customer ID. Please try again.")
        Home()
        return   
    
    menu = { 
        "1": 20, "2": 25, "3": 25, "4": 25, "5": 30, "6": 30, "7": 50, "8": 50,
        "9": 70, "10": 70, "11": 110, "12": 110, "13": 110, "14": 110, "15": 110, 
        "16": 110, "17": 110, "18": 120, "19": 120, "20": 140, "21": 140, "22": 140, 
        "23": 140, "24": 140, "25": 140, "26": 140, "27": 150, "28": 150, "29": 15, 
        "30": 15, "31": 20, "32": 20, "33": 90, "34": 90, "35": 110, "36": 110, 
        "37": 110, "38": 110, "39": 130, "40": 130, "41": 130, "42": 140, "43": 60, 
        "44": 60, "45": 60, "46": 60
    }
    
    print("Welcome to Hotel Piyush")
    print(" ")
    print("-------------------------------------------------------------------------")
    print("                           Hotel Piyush")
    print("-------------------------------------------------------------------------")
    print("                            Menu Card")
    print("-------------------------------------------------------------------------")
    print("\n BEVERAGES                              26 Dal Fry................ 140.00")
    print("----------------------------------      27 Dal Makhani............ 150.00")
    print(" 1  Regular Tea............. 20.00      28 Dal Tadka.............. 150.00")
    print(" 2  Masala Tea.............. 25.00")
    print(" 3  Coffee.................. 25.00      ROTI")
    print(" 4  Cold Drink.............. 25.00     ----------------------------------")
    print(" 5  Bread Butter............ 30.00      29 Plain Roti.............. 15.00")
    print(" 6  Bread Jam............... 30.00      30 Butter Roti............. 15.00")
    print(" 7  Veg. Sandwich........... 50.00      31 Tandoori Roti........... 20.00")
    print(" 8  Veg. Toast Sandwich..... 50.00      32 Butter Naan............. 20.00")
    print(" 9  Cheese Toast Sandwich... 70.00")
    print(" 10 Grilled Sandwich........ 70.00      RICE") 
    print("                                       ----------------------------------")
    print(" SOUPS                                  33 Plain Rice.............. 90.00")
    print("----------------------------------      34 Jeera Rice.............. 90.00")
    print(" 11 Tomato Soup............ 110.00      35 Veg Pulao.............. 110.00")
    print(" 12 Hot & Sour............. 110.00      36 Peas Pulao............. 110.00")
    print(" 13 Veg. Noodle Soup....... 110.00")
    print(" 14 Sweet Corn............. 110.00      SOUTH INDIAN")
    print(" 15 Veg. Manchow........... 110.00     ----------------------------------")
    print("                                        37 Plain Dosa............. 100.00")
    print(" MAIN COURSE                            38 Onion Dosa............. 110.00")
    print("----------------------------------      39 Masala Dosa............ 130.00")
    print(" 16 Shahi Paneer........... 110.00      40 Paneer Dosa............ 130.00")
    print(" 17 Kadai Paneer........... 110.00      41 Rice Idli.............. 130.00")
    print(" 18 Handi Paneer........... 120.00      42 Sambhar Vada........... 140.00")
    print(" 19 Palak Paneer........... 120.00")
    print(" 20 Chilli Paneer.......... 140.00      ICE CREAM")
    print(" 21 Matar Mushroom......... 140.00     ----------------------------------")
    print(" 22 Mix Veg................ 140.00      43 Vanilla................. 60.00")
    print(" 23 Jeera Aloo............. 140.00      44 Strawberry.............. 60.00")
    print(" 24 Malai Kofta............ 140.00      45 Pineapple............... 60.00")
    print(" 25 Aloo Matar............. 140.00      46 Butter Scotch........... 60.00")
    print("Press 0 to end Order")
    
    while True:
        order = input("Enter your order: ")
        if order == "0":
            break
        if order in menu:
            totalbill += menu[order]
        else:
            print("Invalid choice, please try again.")

    print(" ")
    print(f"Total Bill = {totalbill} INR")
    print(" ")
    print("Thank you for visiting Hotel Piyush..")
    n = int(input("0-BACK\n -> "))
    if n == 0:
        Home()
    else:
        exit() 

def Payment():
    global totalbill, booked_rooms, valid_customer_ids
    print("Processing Payment")
    customer_id = input("Please enter your customer ID: ")

    if customer_id not in valid_customer_ids:
        print("Invalid customer ID. Please try again.")
        Home()   
        return
    
    room_details = valid_customer_ids[customer_id]
    booking_price = room_details["Price"]
    grand_total = totalbill + booking_price
    
    print(f"Your room charge is {booking_price} INR")
    print(f"Your restaurant bill is {totalbill} INR")
    print(f"Your grand total bill is {grand_total} INR")
    
    amount = int(input("Enter the amount to pay: "))
    if amount >= grand_total:
        print("Please select a payment method:")
        print("1. Cash")
        print("2. Credit/Debit Card")
        print("3. UPI")
        method = int(input("-> "))
        
        if method == 1:
            print("You have selected Cash. Please pay at the counter.")
        elif method == 2:
            print("You have selected Credit/Debit Card. Please swipe your card at the terminal.")
        elif method == 3:
            print("You have selected UPI. Please scan the QR code to complete the payment.")
        else:
            print("Invalid choice. Please try again.")
        
        print("Payment done successfully!")
    else:
        print("Please enter valid  payment amount. Please try again.")
        Payment()    
    
    n = int(input("0-BACK\n -> "))
    if n == 0:
        Home()
    else:
        exit()

def Record():
    print("Booking Records")
    print(booked_rooms)
    n = int(input("0-BACK\n -> "))
    if n == 0:
        Home()
    else:
        exit()
 
n = int(input("Enter the number of times to execute: "))
for i in range(n):
    Home()
